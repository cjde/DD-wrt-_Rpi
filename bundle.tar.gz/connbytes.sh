#!/bin/sh
# Divide by 5 because this is acumulated on the 5 minute interval. 
# Line in the connections file that we are looking for :
#   1             2            3         4    5   6      7       8     9   10
#Summary 192.168.2.5:Jhdbig   Total  1802196 / 3967857  Delta  545706 / 658847

grep "Summary $1" /tmp/CountConnection.out | awk '{print int(($8/5)+0.5); print int(($10/5)+0.5)}'


