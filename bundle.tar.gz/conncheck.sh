#!/bin/sh
host=$1 

#Variables that are used in the "getter script " 
# RTR=192.168.2.99
# NET=192.168.2
# CONTRACK_RAW=/tmp/ipconntrack.raw
CONTRACK_COOKED=/tmp/ipconntrack.out

#go get the file and build the output if needed 
/home/pi/traffic/get_ip_conntrack.sh

# now get the connections for this ip address 
grep $host $CONTRACK_COOKED | awk '{print $2 ;print $3 }'

